
CPU-Z Vintage Edition Readme file
----------------------------------

Version 1.03
January 2021
Contact : cpuz@cpuid.com
Web page: https://www.cpuid.com/softwares/cpu-z.html

Configuration file (cpuz.ini)
------------------------------

The configuration file must be named cpuz.ini and be present at the same directory level
as cpuz.exe. It contains the following :

[CPU-Z]
VERSION=x.x.x.x
TextFontName=
TextFontSize=14
TextFontColor=000080
LabelFontName=
LabelFontSize=14
ACPI=1
PCI=1
MaxPCIBus=256
DMI=1
Sensor=1
SMBus=1
Display=1
Chipset=1
SPD=1

- TextFontName : Font used for the information boxes. 
- TextFontSize : Size of the font used for the information boxes. 
- TextFontColor : Color of the font used for the information boxes. Value is expressed in hexadecimal, and consists in a classic Red/Green/Blue color code : RRGGBB 
- LabelFontName : Font used for the label boxes. 
- LabelFontSize : Size of the font used for the label boxes. 
- Sensor : Set to OFF (or 0) disables sensor chip detection and voltages measurement. 1 to enable.
- PCI : Set to OFF (or 0) disables the PCI information. This disables chipset, SPD and, depending on the hardware, sensoring information. 1 to enable.
- MaxPCIBus : Sets the maximum PCI bus to scan. Default value is 256.
- DMI : Set to OFF (or 0) disables the DMI (Desktop Management Interface) information. This concerns BIOS vendor and version, motherboard vendor and revision. 1 to enable. 
- SMBus : Set to OFF (or 0) disables SMBus information : SPD, and, depending on the hardware, sensoring information. 1 to enable.
- Display : Set to OFF (or 0) disables the video card information reported in the validator. 1 to enable.
- Chipset : set to OFF (or 0) disables the memory controller and southbridge information. 1 to enable.
- SPD : set to 0 to disable SPD reading. 1 to enable.

Parameters
----------

-txt=filename : Launch CPU-Z in ghost mode (no interface appears) and generates the register dump file (.txt) 
in the same directory as the exe file.

-html=filename : Same as "-txt" except it generates the html report.

-bench : runs CPU-Z without interface, runs the benchmark, and saves the result in a TXT file named like the machine.


Keys
----

F5 : save the current tab in a bmp file
F6 : save the current tab in the clipboard
F7 : save cvf file in the current directory


Cache Latency Tool
------------------

The cache latency tool can be downloaded at that address : http://download.cpuid.com/misc/latency.zip


History
-------
--------------------------------------------------------------------------------------------------
1.03 - January 2021
- SPM memory support.
- Improved support of Intel Pentium Overdrive.
- Fix validation issues.

--------------------------------------------------------------------------------------------------
1.02 - August 2020
- AMD K5 model 0 (SSA/5).
- Improved support of Cyrix Cx486DRx2/DRu2.
- Improved support of Ti486SXL/SXL2.
- Intel 430FX chipset.
- Opti 82C822 chipset.
- VIA VT82C505/VT82C486 chipset.

--------------------------------------------------------------------------------------------------
1.01 - November 2019
- First release.
